GeoProcess_Scatter_Gather.py specifies the Scatter-Gather method as mentioned in report.
GeoProcess_Gather.py specifies the Gather method

outputs_1n1c_ScatterGather, output_1n8c_Scatter_Gather, outputs_2n8c_Scatter_Gather contains the outputs of executing GeoProcess_Scatter_Gather.py by using Job_Script.

outputs_1n1c_Gather, output_1n8c_Gather, outputs_2n8c_Gather contains the outputs of executing GeoProcess_Gather.py by using Job_Script.

scatter-gather.png, gather.png specify the workflow of parallelized program in my comprehension